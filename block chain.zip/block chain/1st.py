import datetime

class Event:
    def _init_(self, name, start_time, end_time):
        self.name = name
        self.start_time = datetime.datetime.strptime(start_time, "%H:%M").time()
        self.end_time = datetime.datetime.strptime(end_time, "%H:%M").time()

    def _str_(self):
        return f"{self.name}, Start: {self.start_time.strftime('%H:%M')}, End: {self.end_time.strftime('%H:%M')}"

    def overlaps(self, other_event):
        return (self.start_time <= other_event.end_time and self.end_time >= other_event.start_time)

def find_conflicts(events):  # Correct indentation here
    conflicts = []
    for i in range(len(events)):
        for j in range(i + 1, len(events)):
            if events[i].overlaps(events[j]):
                conflicts.append((events[i], events[j]))
    return conflicts

def suggest_resolution(event, conflicting_events, working_hours_start="08:00", working_hours_end="18:00"): # Correct indentation here
    working_start = datetime.datetime.strptime(working_hours_start, "%H:%M").time()
    working_end = datetime.datetime.strptime(working_hours_end, "%H:%M").time()

    last_conflicting_end = working_start
    for conflicting_event in conflicting_events:
        last_conflicting_end = max(last_conflicting_end, conflicting_event.end_time)

    suggested_start = last_conflicting_end
    event_duration = datetime.datetime.combine(datetime.date.today(), event.end_time) - datetime.datetime.combine(datetime.date.today(), event.start_time)
    suggested_end = (datetime.datetime.combine(datetime.date.today(), suggested_start) + event_duration).time()

    if suggested_end <= working_end:
        return suggested_start.strftime('%H:%M'), suggested_end.strftime('%H:%M')
    else:
        return None, None

def create_event_from_input(): # Correct indentation here
    while True:
        try:
            name = input("Enter event name: ")
            start_time_str = input("Enter start time (HH:MM): ")
            end_time_str = input("Enter end time (HH:MM): ")

            datetime.datetime.strptime(start_time_str, "%H:%M").time()
            datetime.datetime.strptime(end_time_str, "%H:%M").time()

            return Event(name, start_time_str, end_time_str)
        except ValueError:
            print("Invalid input. Please enter time in HH:MM format (e.g., 09:00).")
        except Exception as e:
            print(f"An error occurred: {e}")


events = []
while True:  # Correct indentation here
    print("\nOptions:")
    print("1. Add event")
    print("2. View schedule and find conflicts")
    print("3. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
        new_event = create_event_from_input()
        if new_event:
            events.append(new_event)

    elif choice == '2':
        events.sort(key=lambda x: x.start_time)
        print("\nSorted Schedule:")
        if not events:
            print("No events scheduled yet.")
        else:
            for event in events:
                print(event)

            conflicts = find_conflicts(events)

            print("\nConflicting Events:")
            if not conflicts:
                print("No conflicts found.")
            else:
                for event1, event2 in conflicts:
                    print(f"{event1.name} and {event2.name}")

            print("\nSuggested Resolutions:")
            for event1, event2 in conflicts:
                if event1.name == "Workshop B":
                    conflicting_events = [ev for ev in events if ev != event1 and ev.overlaps(event1)]
                    suggested_start, suggested_end = suggest_resolution(event1, conflicting_events)
                    if suggested_start and suggested_end:
                        print(f"Reschedule {event1.name} to Start: {suggested_start}, End: {suggested_end}")
                    else:
                        print(f"No suitable slot found for {event1.name} within working hours.")

    elif choice == '3':
        break

    else:
        print("Invalid choice. Please try again.")